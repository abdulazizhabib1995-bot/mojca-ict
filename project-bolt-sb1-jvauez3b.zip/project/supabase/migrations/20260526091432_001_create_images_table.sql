/*
  # Create Images Table and Storage Bucket

  1. New Tables
    - `images`
      - `id` (uuid, primary key) - Unique identifier for the image
      - `filename` (text) - Original filename
      - `storage_path` (text) - Path in Supabase storage bucket
      - `public_url` (text) - Public URL for viewing
      - `mime_type` (text) - Image MIME type
      - `size` (bigint) - File size in bytes
      - `created_at` (timestamptz) - Upload timestamp

  2. Storage Bucket
    - `images` bucket for storing uploaded images
    - Public access enabled for viewing images

  3. Security
    - Enable RLS on `images` table
    - Allow public read access for image viewing
    - Only authenticated uploads (handled at application level with service role)

  4. Important Notes
    - Images are publicly viewable via direct links
    - Upload is managed through the admin interface
    - Storage bucket is configured for public access
*/

-- Create images table
CREATE TABLE IF NOT EXISTS images (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  filename text NOT NULL,
  storage_path text NOT NULL UNIQUE,
  public_url text NOT NULL,
  mime_type text DEFAULT 'image/jpeg',
  size bigint DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE images ENABLE ROW LEVEL SECURITY;

-- Public read policy - anyone can view images
CREATE POLICY "Public can view images"
  ON images FOR SELECT
  TO public
  USING (true);

-- Create index for faster lookups
CREATE INDEX IF NOT EXISTS idx_images_created_at ON images(created_at DESC);
