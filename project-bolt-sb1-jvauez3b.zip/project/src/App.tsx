import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import ImageViewer from './pages/ImageViewer';
import Upload from './pages/Upload';
import Dashboard from './pages/Dashboard';

function App() {
  return (
    <BrowserRouter>
      <Routes>
        {/* Public image viewer - shows only the image */}
        <Route path="/image/:id" element={<ImageViewer />} />

        {/* Admin routes */}
        <Route path="/upload" element={<Upload />} />
        <Route path="/dashboard" element={<Dashboard />} />

        {/* Redirect root to upload */}
        <Route path="/" element={<Navigate to="/upload" replace />} />

        {/* 404 fallback */}
        <Route path="*" element={<NotFound />} />
      </Routes>
    </BrowserRouter>
  );
}

function NotFound() {
  return (
    <div className="min-h-screen bg-gray-950 flex items-center justify-center">
      <div className="text-center">
        <h1 className="text-4xl font-bold text-white mb-4">Page Not Found</h1>
        <a href="/upload" className="text-emerald-400 hover:text-emerald-300 underline">
          Go to Upload
        </a>
      </div>
    </div>
  );
}

export default App;
