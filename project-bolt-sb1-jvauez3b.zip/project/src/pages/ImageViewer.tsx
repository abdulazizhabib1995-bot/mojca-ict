import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { supabase, Image } from '../lib/supabase';
import { Loader2 } from 'lucide-react';

export default function ImageViewer() {
  const { id } = useParams<{ id: string }>();
  const [image, setImage] = useState<Image | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [scale, setScale] = useState(1);

  useEffect(() => {
    async function fetchImage() {
      if (!id) {
        setError('No image ID provided');
        setLoading(false);
        return;
      }

      try {
        const { data, error: fetchError } = await supabase
          .from('images')
          .select('*')
          .eq('id', id)
          .maybeSingle();

        if (fetchError) {
          setError('Failed to load image');
          return;
        }

        if (!data) {
          setError('Image not found');
          return;
        }

        setImage(data);
      } catch (err) {
        setError('Failed to load image');
      } finally {
        setLoading(false);
      }
    }

    fetchImage();
  }, [id]);

  // Handle pinch zoom on mobile
  useEffect(() => {
    let initialDistance = 0;
    let initialScale = 1;

    const handleTouchStart = (e: TouchEvent) => {
      if (e.touches.length === 2) {
        initialDistance = Math.hypot(
          e.touches[0].clientX - e.touches[1].clientX,
          e.touches[0].clientY - e.touches[1].clientY
        );
        initialScale = scale;
      }
    };

    const handleTouchMove = (e: TouchEvent) => {
      if (e.touches.length === 2) {
        e.preventDefault();
        const currentDistance = Math.hypot(
          e.touches[0].clientX - e.touches[1].clientX,
          e.touches[0].clientY - e.touches[1].clientY
        );
        const newScale = Math.max(0.5, Math.min(4, initialScale * (currentDistance / initialDistance)));
        setScale(newScale);
      }
    };

    window.addEventListener('touchstart', handleTouchStart, { passive: true });
    window.addEventListener('touchmove', handleTouchMove, { passive: false });

    return () => {
      window.removeEventListener('touchstart', handleTouchStart);
      window.removeEventListener('touchmove', handleTouchMove);
    };
  }, [scale]);

  // Handle scroll zoom on desktop
  useEffect(() => {
    const handleWheel = (e: WheelEvent) => {
      if (e.ctrlKey) {
        e.preventDefault();
        const delta = e.deltaY > 0 ? 0.9 : 1.1;
        setScale((s) => Math.max(0.5, Math.min(4, s * delta)));
      }
    };

    window.addEventListener('wheel', handleWheel, { passive: false });
    return () => window.removeEventListener('wheel', handleWheel);
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <Loader2 className="w-10 h-10 text-gray-400 animate-spin" />
      </div>
    );
  }

  if (error || !image) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="text-center">
          <p className="text-gray-400 text-lg">{error || 'Image not found'}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black flex items-center justify-center p-4 overflow-hidden">
      <img
        src={image.public_url}
        alt={image.filename}
        className="max-w-full max-h-full object-contain transition-transform duration-150"
        style={{ transform: `scale(${scale})` }}
        draggable={false}
        onClick={() => setScale(scale === 1 ? 1.5 : 1)}
      />
    </div>
  );
}
